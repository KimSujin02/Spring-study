package com.kgitbank.mvc02;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BbsController {
	
	@Autowired
	BbsDAO dao;
	
	@RequestMapping("insert2")
	public void insert(String id, String title, String content, String writer) throws Exception {
		System.out.println("insert2 ��û�Ǿ����ϴ�.");
		dao.insert(id, title, content, writer);
	}
	
	@RequestMapping("delete2")
	public void delete(String writer) throws Exception {
		System.out.println("delete2 ��û�Ǿ����ϴ�.");
		dao.delete(writer);
	}
	
	@RequestMapping("select2")
	public void select(String writer, Model model) throws Exception {
		System.out.println("select2 ��û�Ǿ����ϴ�.");
		BbsDTO dto2 = dao.select(writer);
		model.addAttribute("dto2", dto2);
		
	}
}
