package com.kgitbank.mvc03;

public class insert2 {

}
