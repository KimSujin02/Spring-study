package com.kgitbank.mvc04;

import java.sql.*;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

@Repository
public class ReplyDAO {
	public void insert(String content, String writer) throws Exception {
		
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("����̹� ���� ����");
		
		String url = "jdbc:mysql://localhost:3307/spring";
		String user = "root"; 
		String password = "1234"; 
		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("DB���� ����");

		String sql = "insert into reply VALUES(?, ?)";
		PreparedStatement ps= con.prepareStatement(sql);
		ps.setString(1, content);
		ps.setString(2, writer);
		
		//4 SQL ����
		ps.executeUpdate();
		System.out.println("SQL���� ����");
		
	}
}
