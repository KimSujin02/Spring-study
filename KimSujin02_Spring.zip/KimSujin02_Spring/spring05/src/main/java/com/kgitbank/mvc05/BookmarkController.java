package com.kgitbank.mvc05;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.*;

@Controller
public class BookmarkController {
	
	@Autowired
	BookmarkDAO dao;
	
	@RequestMapping("insert")
	public void insert(BookmarkDTO dto) throws Exception {
		System.out.println(dto.getId());
		System.out.println(dto.getName());
		System.out.println(dto.getSite());
		dao.insert(dto);
	}
	@RequestMapping("update")
	public void update(BookmarkDTO dto) throws Exception {
		System.out.println(dto.getId());
		System.out.println(dto.getName());
		dao.update(dto);
	}
	
	@RequestMapping("delete")
	public void delete(BookmarkDTO dto) throws Exception {
		System.out.println(dto.getId());
		dao.delete(dto);
	}
	
	@RequestMapping("selectOne")
	public void selectOne(BookmarkDTO bookmarkDTO, Model model) throws Exception {
		System.out.println(bookmarkDTO.getId());
		BookmarkDTO dto = dao.selectOne(bookmarkDTO);
		model.addAttribute("result", dto);
	}
	
	@RequestMapping("selectAll")
	public void selectAll(Model model) throws Exception {
		System.out.println("��ü �˻��� ��û��");
		List<BookmarkDTO> list = dao.selectAll();
		model.addAttribute("list", list);
		//model�� �˻��� �ÿ� ������� �ѱ�� ������ �Ѵ�.
	}
}
