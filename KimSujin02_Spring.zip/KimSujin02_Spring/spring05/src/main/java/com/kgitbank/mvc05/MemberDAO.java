package com.kgitbank.mvc05;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class MemberDAO {
	
	@Autowired
	SqlSessionTemplate my;
	
	public List<MemberDTO> memberAll() throws Exception {
		return my.selectList("member.memberAll");
	}
}
