package com.kgitbank.mvcfinal;

public class selectAll {

}
